using System;

namespace laba_11_1_op
{
    public partial class Form1 : Form
    {
        int n = 0;
        int result1 = 0;
        int result2 = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void hScrollBar1_Scroll(object sender, ScrollEventArgs e)
        {
            textBox2.Text = Convert.ToString(hScrollBar1.Value);
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            //
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            n = Convert.ToInt32(textBox2.Text);
            hScrollBar1.Value = (int)n;
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            //
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            //
        }

        private void button1_Click(object sender, EventArgs e)
        {
            result1 = 0;
            result2 = 0;
            for (int i = 1; i <= n; i++)
            {
                result1 += Convert.ToInt32(Math.Pow(i, 5));
            }
            textBox6.Text = Convert.ToString(result1);
            result2 = Convert.ToInt32((Math.Pow(n, 2) * Math.Pow(n + 1, 2) * (2 * (Math.Pow(n, 2)) + 2 * n - 1))/12);
            textBox5.Text = Convert.ToString(result2);
        }
    }
}
