using static System.Windows.Forms.VisualStyles.VisualStyleElement.Rebar;
using System.Xml.Linq;
using System.Diagnostics;
using System;

namespace laba_11_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public class Znak
        {
            string[] LNames = { "����", "������", "����", "������", "�����", "���", "���", "���", "�����", "�����", "����" };
            string[] FNames = { "�����", "�����", "��", "���", "���", "���", "���", "���", "���", "���", "���", "�����" };
            public string FirstName;
            public string LastName;
            public string ZodiacSign;
            public DateTime BirthDay;
            Random rand = new Random();
            public Znak(string znak) : base()
            {
                FirstName = znak.Substring(0, znak.IndexOf(" "));
                znak = znak.Remove(0, FirstName.Length + 1);
                LastName = znak.Substring(0, znak.IndexOf("."));
                znak = znak.Remove(0, LastName.Length + 2);
                BirthDay = DateTime.Parse(znak.Substring(0, znak.IndexOf(" ")));
                ZodiacSign = GetZodiac(BirthDay);
            }
            public Znak() :
                base()
            {
                FirstName = FNames[rand.Next(FNames.Length)];
                LastName = LNames[rand.Next(LNames.Length)];
                BirthDay = new DateTime(rand.Next(1900, 2024), rand.Next(1, 12), rand.Next(1, 28));
                ZodiacSign = GetZodiac(BirthDay);
            }
            public override string ToString()
            {
                return $"{FirstName} {LastName}. {BirthDay.ToShortDateString()} {ZodiacSign}";
            }


            public string GetZodiac(DateTime bday)
            {
                if ((bday.Day >= 21 & bday.Month == 1) | (bday.Day <= 20 & bday.Month == 2))
                {
                    return ZodiacSign = "�������";
                }
                if ((bday.Day >= 21 & bday.Month == 2) | (bday.Day <= 20 & bday.Month == 3))
                {
                    return ZodiacSign = "����";
                }
                if ((bday.Day >= 21 & bday.Month == 3) | (bday.Day <= 19 & bday.Month == 4))
                {
                    return ZodiacSign = "����";
                }
                if ((bday.Day >= 20 & bday.Month == 4) | (bday.Day <= 20 & bday.Month == 5))
                {
                    return ZodiacSign = "�����";
                }
                if ((bday.Day >= 21 & bday.Month == 5) | (bday.Day <= 21 & bday.Month == 6))
                {
                    return ZodiacSign = "��������";
                }
                if ((bday.Day >= 22 & bday.Month == 6) | (bday.Day <= 22 & bday.Month == 7))
                {
                    return ZodiacSign = "���";
                }
                if ((bday.Day >= 23 & bday.Month == 7) | (bday.Day <= 22 & bday.Month == 8))
                {
                    return ZodiacSign = "���";
                }
                if ((bday.Day >= 23 & bday.Month == 8) | (bday.Day <= 22 & bday.Month == 9))
                {
                    return ZodiacSign = "����";
                }
                if ((bday.Day >= 23 & bday.Month == 9) | (bday.Day <= 23 & bday.Month == 10))
                {
                    return ZodiacSign = "����";
                }
                if ((bday.Day >= 24 & bday.Month == 10) | (bday.Day <= 21 & bday.Month == 11))
                {
                    return ZodiacSign = "��������";
                }
                if ((bday.Day >= 22 & bday.Month == 11) | (bday.Day <= 21 & bday.Month == 12))
                {
                    return ZodiacSign = "�������";
                }
                if ((bday.Day >= 22 & bday.Month == 12) | (bday.Day <= 20 & bday.Month == 1))
                {
                    return ZodiacSign = "�������";
                }
                return ZodiacSign = "�����������";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void listBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            //
        }

        public void button1_Click(object sender, EventArgs e)
        {
            FileInfo file = new FileInfo("Input.txt");
            using (FileStream fs1 = file.Open(FileMode.Create)) { }
            using (StreamWriter potok = File.AppendText("Input.txt"))
            {
                for (int i = 0; i < 10; i++)
                {
                    Znak uno = new Znak();
                    potok.WriteLine(uno.ToString());
                }
            }
            int count = 0;
            string line;
            listBox1.Items.Clear();
            TextReader reader = new StreamReader("Input.txt");
            while ((line = reader.ReadLine()) != null)
            {
                listBox1.Items.Add(line);
                count++;
            }
            reader.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        public void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            FileInfo file = new FileInfo("Input.txt");
            using (FileStream fs1 = file.Open(FileMode.Create)) 
            {
                
            }
        }

        public void button3_Click(object sender, EventArgs e)
        {
            listBox2.Items.Clear();
            int C = 0;
            for (int i = 0; i < 10; i++)
            {
                if (listBox1.Items[i].ToString().ToLower().Contains(textBox1.Text.ToLower()))
                {
                    int n = textBox1.Text.ToString().Length;
                    if (n != 0)
                    {
                        listBox2.Items.Add(listBox1.Items[i]);
                        C += 1;
                    }
                }
            }
            if (C == 0)
            {
                listBox2.Items.Add("����� ����� �� �������");
            }

        }

        public void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        public void button4_Click(object sender, EventArgs e)
        {
            Process.Start("explorer.exe", "Input.txt");
        }

        public void button5_Click(object sender, EventArgs e)
        {
            FileInfo sorted = new FileInfo("sorted.txt");
            using (FileStream fs2 = sorted.Open(FileMode.Create)) { }
            using (StreamWriter potok = File.AppendText("sorted.txt"))
            {
                if (listBox2.Items.Count > 0)
                {
                    for (int i = 0; i < listBox2.Items.Count; i++)
                    {
                        potok.WriteLine(listBox2.Items[i].ToString());
                    }
                }
                else
                { potok.WriteLine("�� �������."); }
            }
            Process.Start("explorer.exe", "sorted.txt");
        }

        public void button6_Click(object sender, EventArgs e)
        {
            List<Znak> ForSort = new();
            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                ForSort.Add(new Znak(listBox1.Items[i].ToString()));
            }
            var ListSorted = ForSort.OrderByDescending(Z => Z.BirthDay);
            FileInfo file = new FileInfo("Input.txt");
            using (FileStream fs1 = file.Open(FileMode.Create)) { }
            using (StreamWriter potok = File.AppendText("Input.txt"))
            {
                foreach (Znak item in ListSorted)
                {
                    potok.WriteLine(item.ToString());
                }
            }
            int count = 0;
            string line;
            listBox1.Items.Clear();
            TextReader reader = new StreamReader("Input.txt");
            while ((line = reader.ReadLine()) != null)
            {
                listBox1.Items.Add(line);
                count++;
            }
            reader.Close();
        }
    }
}
